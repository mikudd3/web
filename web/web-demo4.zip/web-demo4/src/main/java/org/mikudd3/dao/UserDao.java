package org.mikudd3.dao;

import org.mikudd3.pojo.User;

import java.sql.*;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class UserDao {
    public void addRegisterInfo(User user) {
        Connection con = null;
        Statement stmt = null;
        //加载驱动
        try {
            Class.forName("com.mysql.jdbc.Driver");
            System.out.println("驱动加成功+++++++++++++");
            //创建连接
            con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/test?characterEncoding=utf8", "root", "123456");
            System.out.println("创建连接成功+++++++++");

            //创建对象
            stmt = con.createStatement();
            System.out.println("创建对象成功+++++++++");
            String sql = "insert into userInfo (uname,upwd,uage,uaddress) values('" + user.getUsername() + "','" + user.getUserPassword() + "','" + user.getUserAge() + "','" + user.getUserAddress() + "')";
            System.out.println(sql);
            stmt.executeUpdate(sql);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                stmt.close();
                con.close();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }
}
