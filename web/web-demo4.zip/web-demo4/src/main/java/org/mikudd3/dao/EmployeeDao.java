package org.mikudd3.dao;

import com.mysql.cj.xdevapi.PreparableStatement;
import org.mikudd3.jdbc.JdbcUtil;
import org.mikudd3.pojo.Employee;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class EmployeeDao {


    public Employee findEmployeeById(Integer empId) throws SQLException {
        Employee employee = null;

        //获取数据库连接
        Connection conn = JdbcUtil.getConn();

        //sql
        String sql = "select * from employees where employee_id = ?";
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setInt(1, empId);

        ResultSet rs = pstmt.executeQuery();

        while (rs.next()) {
            Integer id = rs.getInt("employee_id");
            String name = rs.getString("employee_name");
            Integer gender = rs.getInt("employee_gender");
            String phone = rs.getString("employee_phone");
            String email = rs.getString("employee_email");
            String addr = rs.getString("employee_addr");
            employee = new Employee(id, name, gender, phone, email, addr);
        }

        JdbcUtil.closeConn();
        rs.close();
        return employee;
    }
}
