package org.mikudd3.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class WelcomeServlet30 extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public WelcomeServlet30() {

    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        PrintWriter output = resp.getWriter();
        output.print("doPost--hello servlet3.0");
        output.close();
    }
}
