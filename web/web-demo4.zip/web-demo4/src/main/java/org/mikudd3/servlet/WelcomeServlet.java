package org.mikudd3.servlet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class WelcomeServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 通过 resp 获取输出对象 out （等价于 JSP 中的内置对象 out）
        PrintWriter out = resp.getWriter();
        out.print("doGet  --  Hello Servlet");

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        // 通过 resp 获取输出对象 out （等价于 JSP 中的内置对象 out）
        PrintWriter out = resp.getWriter();
        out.print("doPost  --  Hello Servlet");

    }
}
