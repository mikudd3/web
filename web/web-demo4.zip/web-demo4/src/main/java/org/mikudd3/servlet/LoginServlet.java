package org.mikudd3.servlet;

import org.mikudd3.dao.UserDao;
import org.mikudd3.pojo.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //将请求的编码与页面保持一致，设置为 UTF-8
        request.setCharacterEncoding("UTF-8");
        //接收视图传来的数据
        String name = request.getParameter("uname");
        String pwd = request.getParameter("upwd");
        String address = request.getParameter("uaddress");
        String uage = request.getParameter("uage");
        int age = Integer.parseInt(uage);
        //将数据封装到 JavaBean 中
        User user = new User(name, pwd, age, address);
        //调用封装业务的 JavaBean ，进行数据库的操作
        UserDao userDao = new UserDao();
        userDao.addRegisterInfo(user);
        //将用户信息放入 session 中
        request.getSession().setAttribute("userInfo", user);
        //注册完毕，跳转到显示页面
        request.getRequestDispatcher("welcome.jsp").forward(request, response);

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
