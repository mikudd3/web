package org.mikudd3.test;

import org.junit.Test;
import org.mikudd3.dao.EmployeeDao;
import org.mikudd3.pojo.Employee;

import java.sql.SQLException;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class EmpTest {

    @Test
    public void testEmp() throws SQLException {
        EmployeeDao employeeDao = new EmployeeDao();

        Employee employee = employeeDao.findEmployeeById(1001);


        System.out.println(employee);
    }
}
