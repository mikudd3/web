/*
 Navicat MySQL Data Transfer

 Source Server         : 本机
 Source Server Type    : MySQL
 Source Server Version : 50717
 Source Host           : localhost:3306
 Source Schema         : goods_project

 Target Server Type    : MySQL
 Target Server Version : 50717
 File Encoding         : 65001

 Date: 25/12/2020 09:01:51
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS goods_project
DEFAULT CHARACTER SET utf8;

-- ----------------------------
-- Table structure for goods
-- ----------------------------
USE goods_project
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods`  (
  `good_id` int(10) NOT NULL AUTO_INCREMENT COMMENT '商品id，用以标识的唯一字段',
  `good_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品名称',
  `good_manufacturer` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '商品生产商',
  `good_price` decimal(10, 2) NULL DEFAULT NULL COMMENT '商品价格',
  `good_state` int(1) NULL DEFAULT NULL COMMENT '商品状态(0表示未上架，1表示上架中，2表示已下架)',
  `good_Inventory` int(10) NULL DEFAULT NULL COMMENT '库存量',
  PRIMARY KEY (`good_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES (2, '旺仔牛奶', '旺旺集团', 6.00, 1, 10000);
INSERT INTO `goods` VALUES (3, '辣条', '卫龙集团', 4.00, 1, 1000);
INSERT INTO `goods` VALUES (4, '雀巢咖啡', '雀巢集团', 6.00, 1, 10000);
INSERT INTO `goods` VALUES (5, '面巾纸', '洁柔', 18.80, 1, 10000);
INSERT INTO `goods` VALUES (6, '方便面', '康师傅', 4.50, 1, 1000);
INSERT INTO `goods` VALUES (7, '纯牛奶', '蒙牛', 2.50, 1, 1000);
INSERT INTO `goods` VALUES (8, '安慕希酸奶', '伊利', 7.00, 1, 1000);
INSERT INTO `goods` VALUES (9, '纯牛奶', '伊利', 2.50, 1, 1000);
INSERT INTO `goods` VALUES (10, '可口可乐', '可口可乐', 3.00, 1, 10000);

SET FOREIGN_KEY_CHECKS = 1;
