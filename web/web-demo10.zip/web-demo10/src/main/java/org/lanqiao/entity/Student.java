package org.lanqiao.entity;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class Student {
}
