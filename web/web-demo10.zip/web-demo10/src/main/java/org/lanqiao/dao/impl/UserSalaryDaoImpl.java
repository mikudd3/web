package org.lanqiao.dao.impl;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.lanqiao.dao.UserSalaryDao;
import org.lanqiao.entity.User;
import org.lanqiao.entity.UserSalary;
import org.lanqiao.util.JDBCUtil;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class UserSalaryDaoImpl implements UserSalaryDao {
    @Override
    public UserSalary queryUserByName(String name) {
        QueryRunner runner = new QueryRunner();
        Connection conn = JDBCUtil.getConnection();
        String sql = "select * from user_salary where name = ?";

        Object[] os = {name};

        UserSalary user = null;

        try {
            user = runner.query(conn, sql, new BeanHandler<UserSalary>(UserSalary.class), os);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user;
    }

    @Override
    public void updateUser(UserSalary user) {
        QueryRunner runner = new QueryRunner();
        Connection conn = JDBCUtil.getConnection();
        String sql = "update user_salary set salary = ? where name = ?";
        Object[] os = {user.getSalary(), user.getId()};
        try {
            runner.update(conn, sql, os);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public UserSalary queryUserById(Integer id) {
        QueryRunner runner = new QueryRunner();
        Connection conn = JDBCUtil.getConnection();
        String sql = "select * from user_salary where id = ?";

        Object[] os = {id};

        UserSalary user = null;

        try {
            user = runner.query(conn, sql, new BeanHandler<UserSalary>(UserSalary.class), os);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user;
    }
}
