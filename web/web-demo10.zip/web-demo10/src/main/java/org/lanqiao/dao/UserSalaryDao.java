package org.lanqiao.dao;

import org.lanqiao.entity.User;
import org.lanqiao.entity.UserSalary;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public interface UserSalaryDao {

    //根据姓名查询user
    UserSalary queryUserByName(String name);

    //修改账户
    void updateUser(UserSalary user);

    //根据id查询账户
    UserSalary queryUserById(Integer id);
}
