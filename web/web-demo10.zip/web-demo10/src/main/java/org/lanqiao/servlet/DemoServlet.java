package org.lanqiao.servlet;


import org.lanqiao.dbutil.ResultSetHandlerDemo;
import org.lanqiao.dbutil.UpdateDemo;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


public class DemoServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        /*// 设置相应内容的格式
        response.setContentType("text/html;charset=utf-8");
        // 获取数据字符串
        String objArray = ResultSetHandlerDemo.arrayHandlerTest();
        // 获取输出的 out 对象
        PrintWriter out = response.getWriter();
        // 输出数据
        out.write(objArray);
        // 关闭 out 对象
        out.close();*/

        /*// 设置相应内容的格式
        response.setContentType("text/html;charset=utf-8");
        // 获取数据字符串
        String objArray = ResultSetHandlerDemo.arrayListHandlerTest();
        // 获取输出的 out 对象
        PrintWriter out = response.getWriter();
        // 输出数据
        out.write(objArray);
        // 关闭 out 对象
        out.close();*/


        // 设置相应内容的格式
        response.setContentType("text/html;charset=utf-8");
        // 获取数据字符串
        String result1 = UpdateDemo.insertTest();
        String result2 = UpdateDemo.updateTest();
        String result3 = UpdateDemo.deleteTest();
        // 获取输出的 out 对象
        PrintWriter out = response.getWriter();
        // 输出数据
        out.write(result1+"<br/>"+result2+"<br/>"+result3);
        // 关闭 out 对象
        out.close();
    }
}