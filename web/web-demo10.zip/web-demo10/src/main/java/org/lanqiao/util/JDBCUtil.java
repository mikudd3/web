package org.lanqiao.util;

import com.mchange.v2.c3p0.ComboPooledDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class JDBCUtil {

    //定义ThreadLocal对象
    private static ThreadLocal<Connection> threadLocal = new ThreadLocal<>();
    //定义数据源
    private static DataSource ds = new ComboPooledDataSource();

    //获取C3PO数据源对象
    public static DataSource getDataSource() {
        return ds;

    }


    //获取Connection对象
    public static Connection getConnection() {
        Connection conn = threadLocal.get();
        try {
            if (conn == null) {
                conn = ds.getConnection();
            }
            threadLocal.set(conn);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    //开启事务
    public static void beginTransaction() {
        Connection conn = getConnection();
        try {
            //手动开启事务
            conn.setAutoCommit(false);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //提交事务
    public static void commitTransaction() {
        Connection conn = threadLocal.get();

        try {
            if (conn != null) {
                //提交事务
                conn.commit();

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    //回滚事务
    public static void rollbackTransaction() {
        Connection conn = threadLocal.get();

        try {
            if (conn != null) {
                //回滚事务
                conn.rollback();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    //关闭连接
    public static void close() {
        Connection conn = threadLocal.get();

        try {
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //移除连接
            threadLocal.remove();
            conn = null;
        }
    }
}
