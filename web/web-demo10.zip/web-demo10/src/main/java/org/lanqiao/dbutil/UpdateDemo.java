package org.lanqiao.dbutil;

import org.apache.commons.dbutils.QueryRunner;

import java.sql.SQLException;

public class UpdateDemo {
    // 增加
    public static String insertTest() {
        QueryRunner runner = new QueryRunner(DataSourceUtil.getDataSourceWithC3P0ByXML());
        // 增加的 SQL 语句
        String insertSql = "insert into student(stuNo,stuName,stuAge)values(?,?,?)";
        // SQL 语句中的置换参数
        Object[] params = {35,"赵六",66};
        int count = 0;
        try {
            // 增删改的通用方法 update()
            count = runner.update(insertSql,params) ;

        }catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return new String("成功增加"+count+"条数据");
    }

    // 删除
    public static String deleteTest() {
        QueryRunner runner = new QueryRunner(DataSourceUtil.getDataSourceWithC3P0ByXML());
        String deleteSql = "delete from student where stuNo = 35";
        int count = 0;
        try{
            count = runner.update(deleteSql) ;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return new String("成功删除"+count+"条数据");
    }

    // 修改
    public static String updateTest() {
        QueryRunner runner = new QueryRunner(DataSourceUtil.getDataSourceWithC3P0ByXML());
        String updateSql = "update student set stuName = ?  ,stuAge = ? where stuNo = ?";
        Object[] params = {"孙琪",27,35};
        int count = 0;
        try     {
            count = runner.update(updateSql,params) ;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return new String("成功修改"+count+"条数据");
    }

}