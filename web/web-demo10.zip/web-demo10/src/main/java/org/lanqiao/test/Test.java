package org.lanqiao.test;

import org.lanqiao.dao.UserDao;
import org.lanqiao.dao.impl.GoodDaoImpl;
import org.lanqiao.entity.Good;
import org.lanqiao.entity.User;

import java.sql.SQLException;
import java.util.List;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class Test {
    public static void main(String[] args) throws SQLException {
        GoodDaoImpl goodDao = new GoodDaoImpl();

        List<Good> goods = goodDao.getGoods();

//        System.out.println(goods);

//        System.out.println(goodDao.getGoodByName("小米"));
    }
}
