package org.lanqiao.dao.impl;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.lanqiao.dao.GoodDao;
import org.lanqiao.entity.Good;
import org.lanqiao.util.DBUtil;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class GoodDaoImpl implements GoodDao {
    @Override
    public List<Good> getGoods() throws SQLException {
        //创建QueryRunner对象
        QueryRunner runner = new QueryRunner(DBUtil.getDataSource());
        String sql = "select * from goods";
        List<Good> goods = null;
        try {
            goods = runner.query(sql, new BeanListHandler<Good>(Good.class));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return goods;
    }

    @Override
    public List<Good> getGoodByName(String goodName) throws SQLException {
        //创建QueryRunner对象
        QueryRunner runner = new QueryRunner(DBUtil.getDataSource());
        String sql = "select * from goods where good_name like ?";
        Object[] os = {"%" + goodName + "%"};
        List<Good> goods = null;
        try {
            goods = runner.query(sql, new BeanListHandler<Good>(Good.class), os);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return goods;
    }

    @Override
    public boolean addGood(Good good) {
        //创建QueryRunner对象
        QueryRunner runner = new QueryRunner(DBUtil.getDataSource());
        String sql = "insert into goods values(null,?,?,?,?,?)";
        Object[] os = {good.getGood_name(), good.getGood_manufacturer(), good.getGood_price(),
                good.getGood_state(), good.getGood_Inventory()};
        int update = 0;
        try {
            update = runner.update(sql, os);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return update > 0;
    }

    @Override
    public boolean updateGood(Good good) {
        //创建QueryRunner对象
        QueryRunner runner = new QueryRunner(DBUtil.getDataSource());
        String sql = "update goods set good_name = ?,good_manufacturer = ?," +
                "good_price = ?,good_state = ?,good_Inventory = ? where good_id = ?";
        Object[] os = {
                good.getGood_name(), good.getGood_manufacturer(), good.getGood_price(),
                good.getGood_state(), good.getGood_Inventory(), good.getGood_id()
        };

        int update = 0;
        try {
            update = runner.update(sql, os);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return update > 0;
    }

    @Override
    public Good getGoodByGoodId(int goodId) throws SQLException {
        //创建QueryRunner对象
        QueryRunner runner = new QueryRunner(DBUtil.getDataSource());
        String sql = "select * from goods where good_id = ?";
        Object[] os = {goodId};
        Good good = null;
        try {
            good = runner.query(sql, new BeanHandler<Good>(Good.class),os);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return good;
    }

    @Override
    public boolean deleteGood(int goodId) {
        //创建QueryRunner对象
        QueryRunner runner = new QueryRunner(DBUtil.getDataSource());
        String sql = "delete from goods where good_id = ?";
        Object[] os = {goodId};
        int update = 0;
        try {
            update = runner.update(sql, os);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return update > 0;
    }
}