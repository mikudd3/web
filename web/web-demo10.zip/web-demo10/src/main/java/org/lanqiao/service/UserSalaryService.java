package org.lanqiao.service;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public interface UserSalaryService {

    Boolean transfer(Integer fromId,Integer toId,Integer transferMoney);
}
