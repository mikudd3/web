package org.lanqiao.dbutil;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.*;
import org.lanqiao.entity.Student;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class ResultSetHandlerDemo {

    //ArrayHandler
    public static String arrayHandlerTest() {
        // 创建 QueryRunner 对象
        QueryRunner runner = new QueryRunner(DataSourceUtil.getDataSourceWithC3P0ByXML());
        Object[] studentObj = null;
        try {
            // 使用 query(String sql,ResultSetHandler<T> rsh) 方法执行查询操作，
            // 并且传入 ArrayHandler 对象作为第二个参数
            studentObj = runner.query("select * from student", new ArrayHandler());
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        // 将数组转为字符串，并返回
        return Arrays.toString(studentObj);
    }

    //ArrayListHandler
    public static String arrayListHandlerTest() {
        // 创建 QueryRunner 对象
        QueryRunner runner = new QueryRunner(DataSourceUtil.getDataSourceWithC3P0ByXML());
        String studentInfo = "";
        try {
            // 使用 query(String sql,ResultSetHandler<T> rsh) 方法执行查询操作，
            // 并且传入 ArrayHandler 对象作为第二个参数
            List<Object[]> studentObjList = runner.query("select * from student", new ArrayListHandler());
            // 将数组转为字符串，并输出
            for (Object[] studentObj : studentObjList) {
                studentInfo += Arrays.toString(studentObj) + "<br/>";
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return studentInfo;
    }

    public static String beanHandlerTest() {
        QueryRunner runner = new QueryRunner(DataSourceUtil.getDataSourceWithC3P0ByXML());
        Student stu = null;
        try {
            // 使用 query(String sql,ResultSetHandler<T> rsh) 方法执行查询操作，
            // 传入 BeanHandler 对象作为第二个参数，
            // 并通过泛型指定封装的 JavaBean 类型是 Student
            stu = runner.query("select * from student", new BeanHandler<Student>(Student.class));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        // 默认调用 Student的toString() 方法进行返回
        return stu.toString();
    }
    // 此处省略前部分方法

    public static String beanListHandlerTest() {
        QueryRunner runner = new QueryRunner(DataSourceUtil.getDataSourceWithC3P0ByXML());
        List<Student> stus = null;
        try {
            stus = runner.query("select * from student", new BeanListHandler<Student>(Student.class));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return stus.toString();
    }


    public static String beanMapHandlerTest() {
        QueryRunner runner = new QueryRunner(DataSourceUtil.getDataSourceWithC3P0ByXML());
        Map<BigDecimal, Student> stusMap = null;
        try {
            // 通过泛型指定 Map 的 key 类型是 BigDecimal；valuel 类型是 Student
            // 再通过构造方法的第二个参数指定用表中的 stuNo 列作为 Map 的 key
            stusMap = runner.query("select * from student", new BeanMapHandler<BigDecimal, Student>(Student.class, "stuNo"));
            System.out.println(stusMap);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        // 获取 map 中 key 值为 15 的学生,并返回
        Student stu = stusMap.get(1);
        return stu.toString();
    }


    public static String mapHandlerTest() {
        QueryRunner runner = new QueryRunner(DataSourceUtil.getDataSourceWithC3P0ByXML());
        Map<String, Object> stuMap = null;
        try {
            // 将结果集中的第一条数据封装到 Map 对象中
            stuMap = runner.query("select * from student", new MapHandler());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return stuMap.toString();
    }


    public static String mapListHandlerTest() {
        QueryRunner runner = new QueryRunner(DataSourceUtil.getDataSourceWithC3P0ByXML());
        List<Map<String, Object>> stusMap = null;
        try {
            // 将结果集中的每条数据都封装到 Map 对象中
            stusMap = runner.query("select * from student", new MapListHandler());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return stusMap.toString();
    }

    public static String columnListHandlerTest() {
        QueryRunner runner = new QueryRunner(DataSourceUtil.getDataSourceWithC3P0ByXML());
        List<String> names = null;
        try {
            // 将结果集中 stuName 一列的值封装到了 List 集合对象中：
            names = runner.query("select * from student", new ColumnListHandler<String>("stuName"));
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        // 调用 Student 的 toString() 方法进行输出
        return names.toString();
    }


    public static String scalarHandlerTest(){
        QueryRunner runner = new QueryRunner(DataSourceUtil.getDataSourceWithC3P0ByXML());
        String stuName = "";
        try{
            // 单值查询：查询学号为 1 的学生姓名
            stuName = runner.query("select stuName from student where stuNo = 1", new ScalarHandler<String>()) ;
        }catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return stuName;
    }
}