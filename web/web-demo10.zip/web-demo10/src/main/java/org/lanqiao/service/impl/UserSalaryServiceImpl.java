package org.lanqiao.service.impl;

import org.lanqiao.dao.UserSalaryDao;
import org.lanqiao.dao.impl.UserSalaryDaoImpl;
import org.lanqiao.entity.User;
import org.lanqiao.entity.UserSalary;
import org.lanqiao.service.UserSalaryService;
import org.lanqiao.util.JDBCUtil;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class UserSalaryServiceImpl implements UserSalaryService {
    @Override
    public Boolean transfer(Integer fromId, Integer toId, Integer transferMoney) {
        Boolean flag = false;
        try {
            //开启事务
            JDBCUtil.beginTransaction();
            UserSalaryDao dao = new UserSalaryDaoImpl();

            //付款方
            UserSalary fromUserSalary = dao.queryUserById(fromId);

            //收款芳
            UserSalary toUserSalary = dao.queryUserById(toId);

            if (transferMoney < fromUserSalary.getSalary()) {
                //可以转账
                Integer fromSalary = fromUserSalary.getSalary() - transferMoney;
                //更新付款方工资
                fromUserSalary.setSalary(fromSalary);

                //收款方余额增加
                Integer toSalary = toUserSalary.getSalary() + transferMoney;
                toUserSalary.setSalary(toSalary);


                //更新账户
                dao.updateUser(fromUserSalary);
                dao.updateUser(toUserSalary);

                System.out.println("转账成功");

                //提交事务
                JDBCUtil.commitTransaction();
                flag = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
            //回滚事务
            JDBCUtil.rollbackTransaction();
        }

        return flag;
    }
}
