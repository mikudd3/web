package org.lanqiao.dbutil;
import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.lanqiao.entity.Student;

import javax.sql.DataSource;
import java.beans.PropertyVetoException;
import java.sql.SQLException;

public class DataSourceUtil {

    // 通过 C3P0 配置文件方式获取数据源对象
    public static DataSource getDataSourceWithC3P0ByXML() {
        // 数据库连接池
        ComboPooledDataSource cpds = new ComboPooledDataSource();
        try {
            // 设置数据库链接信息
            cpds.setDriverClass("com.mysql.jdbc.Driver");
            cpds.setJdbcUrl("jdbc:mysql://localhost:3306/info");
            cpds.setUser("root");
            cpds.setPassword("");
            // 设置连接池信息
            cpds.setInitialPoolSize(10);
            cpds.setMaxPoolSize(20);

        } catch (PropertyVetoException e) {
            e.printStackTrace();
        }
        return cpds;
    }





}