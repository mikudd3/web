package org.lanqiao.entity;

import java.math.BigDecimal;
import java.util.Objects;

public class Good {
    private int good_id;
    private String good_name;
    private String good_manufacturer;
    private BigDecimal good_price;
    private int good_state;
    private int good_Inventory;

    public Good() {
    }

    public Good(String good_name, String good_manufacturer, BigDecimal good_price, int good_state, int good_Inventory) {
        this.good_name = good_name;
        this.good_manufacturer = good_manufacturer;
        this.good_price = good_price;
        this.good_state = good_state;
        this.good_Inventory = good_Inventory;
    }

    public Good(int good_id, String good_name, String good_manufacturer, BigDecimal good_price, int good_state, int good_Inventory) {
        this.good_id = good_id;
        this.good_name = good_name;
        this.good_manufacturer = good_manufacturer;
        this.good_price = good_price;
        this.good_state = good_state;
        this.good_Inventory = good_Inventory;
    }


    public int getGood_id() {
        return good_id;
    }

    public void setGood_id(int good_id) {
        this.good_id = good_id;
    }

    public String getGood_name() {
        return good_name;
    }

    public void setGood_name(String good_name) {
        this.good_name = good_name;
    }

    public String getGood_manufacturer() {
        return good_manufacturer;
    }

    public void setGood_manufacturer(String good_manufacturer) {
        this.good_manufacturer = good_manufacturer;
    }

    public BigDecimal getGood_price() {
        return good_price;
    }

    public void setGood_price(BigDecimal good_price) {
        this.good_price = good_price;
    }

    public int getGood_state() {
        return good_state;
    }

    public void setGood_state(int good_state) {
        this.good_state = good_state;
    }

    public int getGood_Inventory() {
        return good_Inventory;
    }

    public void setGood_Inventory(int good_Inventory) {
        this.good_Inventory = good_Inventory;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Good good = (Good) o;
        return good_id == good.good_id && good_state == good.good_state && good_Inventory == good.good_Inventory && Objects.equals(good_name, good.good_name) && Objects.equals(good_manufacturer, good.good_manufacturer) && Objects.equals(good_price, good.good_price);
    }

    @Override
    public int hashCode() {
        return Objects.hash(good_id, good_name, good_manufacturer, good_price, good_state, good_Inventory);
    }


    @Override
    public String toString() {
        return "Good{" +
                "good_id=" + good_id +
                ", good_name='" + good_name + '\'' +
                ", good_manufacturer='" + good_manufacturer + '\'' +
                ", good_price=" + good_price +
                ", good_state=" + good_state +
                ", good_Inventory=" + good_Inventory +
                '}';
    }
}
