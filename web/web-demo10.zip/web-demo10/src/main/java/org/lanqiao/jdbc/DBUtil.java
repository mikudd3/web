package org.lanqiao.jdbc;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
import com.mchange.v2.c3p0.ComboPooledDataSource;
import java.sql.Connection;
import java.sql.SQLException;

public class DBUtil {
    private static ComboPooledDataSource dataSource;

    static {
        dataSource = new ComboPooledDataSource();
        dataSource.setJdbcUrl("jdbc:mysql://localhost:3306/test");
        dataSource.setUser("root");
        dataSource.setPassword("password");
    }

    public static Connection getConnection() throws SQLException {
        return dataSource.getConnection();
    }
}