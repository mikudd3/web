package org.lanqiao.dao;

import org.lanqiao.entity.User;
import org.lanqiao.jdbc.DBUtil;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import java.sql.*;

public class UserDao {
    public User getUser(int userId) throws SQLException {
        Connection conn = DBUtil.getConnection();
        PreparedStatement stmt = conn.prepareStatement("SELECT * FROM user WHERE user_id=?");
        stmt.setInt(1, userId);
        ResultSet rs = stmt.executeQuery();
        User user = null;
        while (rs.next()) {
            Integer id = rs.getInt("user_id");
            String name = rs.getString("user_name");
            Integer gender = rs.getInt("user_gender");
            Integer age = rs.getInt("user_age");
            String nation = rs.getString("user_nation");
            String email = rs.getString("user_email");
            String phone = rs.getString("user_phone");
            String addr = rs.getString("user_addr");

            //创建对象
            user = new User();
            user.setId(id);
            user.setName(name);
            user.setGender(gender);
            user.setAge(age);
            user.setNation(nation);
            user.setEmail(email);
            user.setPhone(phone);
            user.setAddr(addr);
        }
        rs.close();
        stmt.close();
        conn.close();
        return user;
    }

    public int updateUser(User user) throws SQLException {
        Connection conn = DBUtil.getConnection();
        PreparedStatement stmt = conn.prepareStatement("UPDATE user " +
                "SET user_name=?,user_gender=?,user_age=?,user_nation=?,user_email=?,user_phone=?,user_addr=?" +
                " WHERE user_id=?");
        stmt.setString(1, user.getName());
        stmt.setInt(2, user.getGender());
        stmt.setInt(3, user.getAge());
        stmt.setString(4, user.getNation());
        stmt.setString(5, user.getEmail());
        stmt.setString(6, user.getPhone());
        stmt.setString(7, user.getAddr());
        stmt.setInt(8, user.getId());
        int affectedRows = stmt.executeUpdate();
        stmt.close();
        conn.close();
        return affectedRows;
    }

    public int deleteUser(int userId) throws SQLException {
        Connection conn = DBUtil.getConnection();
        PreparedStatement stmt = conn.prepareStatement("DELETE FROM user WHERE user_id=?");
        stmt.setInt(1, userId);
        int affectedRows = stmt.executeUpdate();
        stmt.close();
        conn.close();
        return affectedRows;
    }

    public int inserUser(User user) throws SQLException {
        Connection conn = DBUtil.getConnection();
        PreparedStatement stmt = conn.prepareStatement("INSERT INTO user(user_name,user_gender,user_age,user_nation,user_email,user_phone,user_addr) VALUES (?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
        stmt.setString(1, user.getName());
        stmt.setInt(2, user.getGender());
        stmt.setInt(3, user.getAge());
        stmt.setString(4, user.getNation());
        stmt.setString(5, user.getEmail());
        stmt.setString(6, user.getPhone());
        stmt.setString(7, user.getAddr());
        int affectedRows = stmt.executeUpdate();
        stmt.close();
        conn.close();
        return affectedRows;
    }
}