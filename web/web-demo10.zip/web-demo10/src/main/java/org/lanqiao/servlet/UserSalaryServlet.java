package org.lanqiao.servlet;

import org.lanqiao.service.UserSalaryService;
import org.lanqiao.service.impl.UserSalaryServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
@WebServlet("/us")
public class UserSalaryServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //获取id
        String id = req.getParameter("id");
        //获取工资
        String salary = req.getParameter("salary");

        //调用方法
        UserSalaryService uss = new UserSalaryServiceImpl();

        //执行转账
        boolean result = uss.transfer(1, Integer.parseInt(id), Integer.parseInt(salary));

        if (result) {
            req.setAttribute("result_msg", "succeed");
            req.getRequestDispatcher("result.jsp").forward(req, resp);
        } else {
            req.setAttribute("result_msg", "fail");
            req.getRequestDispatcher("result.jsp").forward(req, resp);
        }
    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req, resp);
    }
}
