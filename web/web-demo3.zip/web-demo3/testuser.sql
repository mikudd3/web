CREATE
DATABASE /*!32312 IF NOT EXISTS*/`test` /*!40100 DEFAULT CHARACTER SET utf8 */;

SET NAMES utf8mb4;
SET
FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for users
-- ----------------------------
USE
`test`;

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`
(
    `user_id`       int(5) NOT NULL AUTO_INCREMENT,
    `user_name`     varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
    `user_realname` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
    `user_gender`   int(1) NULL DEFAULT NULL,
    `user_age`      int(3) NULL DEFAULT NULL,
    `user_nation`   varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
    `user_email`    varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
    `user_phone`    varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
    `user_addr`     varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
    `user_password` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
    PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 104 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users`
VALUES (1, 'admin', '管理员', 1, 38, '汉族', '1000008qq.com', '17677871925', '四川省泸州市', '123456');
INSERT INTO `users`
VALUES (2, 'zhangsan', '张三', 0, 19, '汉族', '1000009qq.com', '17677871926', '四川省泸州市', '123456');
INSERT INTO `users`
VALUES (3, 'lisi', '李四', 1, 18, '汉族', 'zhangsan@qq.com', '17677776666', '四川省泸州市', '123456');
INSERT INTO `users`
VALUES (4, 'wangwu', '王五', 0, 21, '汉族', '1000001qq.com', '17677871918', '四川省泸州市', '123456');
INSERT INTO `users`
VALUES (5, 'zhaoliu', '赵六', 1, 32, '汉族', '1000002qq.com', '17677871919', '四川省泸州市', '123456');
INSERT INTO `users`
VALUES (6, 'xiaolan', '小蓝', 0, 43, '汉族', '1000003qq.com', '17677871920', '四川省泸州市', '123456');
INSERT INTO `users`
VALUES (7, '小红', '小红', 1, 24, '汉族', '1000004qq.com', '17677871921', '四川省泸州市', '123456');

SET
FOREIGN_KEY_CHECKS = 1;
