package org.lanqiao.control;

import org.lanqiao.entity.User;
import org.lanqiao.jdbc.JdbcUtil;

import java.sql.*;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class LoginControl {
    public static User login(String username, String password) {

        Connection conn = null;
        User user = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = JdbcUtil.getConn();

            String sql = "SELECT * FROM users WHERE user_name = ? AND user_password = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, password);
            rs = stmt.executeQuery();
            while (rs.next()) {
                Integer id = rs.getInt("user_id");
                String name = rs.getString("user_name");
                String realName = rs.getString("user_realname");
                Integer gender = rs.getInt("user_gender");
                Integer age = rs.getInt("user_age");
                String nation = rs.getString("user_nation");
                String email = rs.getString("user_email");
                String phone = rs.getString("user_phone");
                String addr = rs.getString("user_addr");
                String pass_word = rs.getString("user_password");

                user = new User(id, name, realName,gender,age,nation,email,phone,addr,pass_word);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                try {
                    JdbcUtil.closeConn();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return user;
    }
}