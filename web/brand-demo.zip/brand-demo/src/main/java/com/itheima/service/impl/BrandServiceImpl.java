package com.itheima.service.impl;

import com.itheima.mapper.BrandMapper;
import com.itheima.pojo.Brand;
import com.itheima.pojo.PageBean;
import com.itheima.service.BrandService;
import com.itheima.util.SqlSessionFactoryUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.List;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class BrandServiceImpl implements BrandService {
    SqlSessionFactory factory = SqlSessionFactoryUtils.getSqlSessionFactory();

    /**
     * 查询所有
     *
     * @return
     */
    @Override
    public List<Brand> selectAll() {
        //调用BrandMapper.selectAll()

        //2. 获取SqlSession
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);

        //4. 调用方法
        List<Brand> brands = mapper.selectAll();

        sqlSession.close();

        return brands;
    }


    /**
     * 添加数据
     *
     * @param brand
     */
    @Override
    public void add(Brand brand) {
        //2. 获取SqlSession
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);

        //4. 调用方法
        mapper.add(brand);

        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    @Override
    public void updateBrand(Brand brand) {
        //2. 获取SqlSession对象
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);

        //4. 调用方法
        mapper.updateBrand(brand);

        sqlSession.commit();//提交事务

        //5. 释放资源
        sqlSession.close();
    }

    /**
     * 批量删除
     *
     * @param ids
     */
    @Override
    public void deleteByIds(int[] ids) {
        //2. 获取SqlSession
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);

        //4. 调用方法
        mapper.deleteByIds(ids);

        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }

    @Override
    public void deleteById(Integer id) {
        //2. 获取SqlSession
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);

        //4. 调用方法
        mapper.deleteById(id);

        //提交事务
        sqlSession.commit();
        //释放资源
        sqlSession.close();
    }


    /**
     * 分页查询
     *
     * @param currPage 当前页码
     * @param pageSize 每页展示条数
     * @return
     */
    @Override
    public PageBean<Brand> selectByPage(int currPage, int pageSize) {
        //2. 获取SqlSession
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);
        //计算开始索引
        int begin = (currPage - 1) * pageSize;
        int size = pageSize;
        //5.查询当前页数据
        List<Brand> rows = mapper.selectByPage(begin, size);
        //查询总数据数量
        int totalCount = mapper.selectTotalCount();
        //封装为PageBean对象
        PageBean<Brand> brandPageBean = new PageBean<Brand>(totalCount, rows);
        //释放资源
        sqlSession.close();
        //返回对象
        return brandPageBean;
    }

    /**
     * 分页条件查询
     *
     * @param currPage
     * @param pageSize
     * @param brand
     * @return
     */
    @Override
    public PageBean<Brand> selectByPageAndCondition(int currPage, int pageSize, Brand brand) {
        //2. 获取SqlSession
        SqlSession sqlSession = factory.openSession();
        //3. 获取BrandMapper
        BrandMapper mapper = sqlSession.getMapper(BrandMapper.class);
        //计算开始索引
        int begin = (currPage - 1) * pageSize;
        int size = pageSize;

        //处理brand查询条件
//        String brandName = brand.getBrandName();
//        if (brandName != null && brandName.length() > 0) {
//            brand.setBrandName("% " + brandName + "%");
//        }
//
//        String companyName = brand.getCompanyName();
//        if (companyName != null && companyName.length() > 0) {
//            brand.setCompanyName("% " + companyName + "%");
//        }

        //5.查询当前页数据
        List<Brand> rows = mapper.selectByPageAndCondition(begin, size, brand);
        //查询条件查询数据数量
        int totalCount = mapper.selectTotalCountBYCondition(brand);

        //封装为PageBean对象
        PageBean<Brand> brandPageBean = new PageBean<Brand>(totalCount, rows);
        //释放资源
        sqlSession.close();
        //返回对象
        return brandPageBean;
    }


}
