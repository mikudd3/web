package org.mikudd3.dao;

import org.mikudd3.pojo.User;

import java.sql.*;
public class UserDao{
    // 更具名字查询用户
    public User getUserByName(String name) {
        Connection con = null;
        User user = new User();
        //加载驱动
        try {
            Class.forName("com.mysql.jdbc.Driver");
            //创建连接
            con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/test", "root", "123456");
            //创建 sql 语句
            String sql = "select uname,uage,uaddress from  userinfo where uname=?";
            // 取得预编译对象
            PreparedStatement pst = con.prepareStatement(sql);
            // 为占位符设置指定内容,即是赋值
            pst.setString(1, name);
            //获取 sql 执行结果
            ResultSet rs= pst.executeQuery();
            while(rs.next()){
                user=new User(rs.getString("uname"),rs.getInt("uage"),rs.getString("uaddress"));
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            try {
                con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return user;
    }
}