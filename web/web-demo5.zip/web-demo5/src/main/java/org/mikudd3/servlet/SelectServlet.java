package org.mikudd3.servlet;


import com.mysql.cj.Session;
import org.mikudd3.dao.UserDao;
import org.mikudd3.pojo.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/SelectServlet")
public class SelectServlet extends javax.servlet.http.HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //将请求的编码与页面保持一致，设置为UTF-8
        request.setCharacterEncoding("UTF-8");
        //接收视图传来的参数
        String uname = request.getParameter("uname");
        //调用封装业务的 JavaBean，进行数据库的操作
        UserDao userDao = new UserDao();
        //将参数传递到 userDao 中的 getUserByName 方法 并且传入查询参数
        User user = userDao.getUserByName(uname);
        //将用户信息放入 session 中
        request.setAttribute("user", user);
        //完毕后，跳转到 showUser.jsp 页面
        request.getRequestDispatcher("/demo2/showUser.jsp").forward(request, response);
    }
}
