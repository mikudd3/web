package org.mikudd3.controller;

import org.mikudd3.dao.EmployeeDao;
import org.mikudd3.pojo.Employee;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
@WebServlet("/emp")
public class EmployeeControl extends HttpServlet {
    private EmployeeDao employeeDao = new EmployeeDao();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String empId = req.getParameter("empId");
//        resp.getWriter().write(empId);
        Employee employee = null;
//        System.out.println(empId);
        try {
            employee = employeeDao.findEmployeeById(Integer.valueOf(empId));
        } catch (SQLException e) {
            e.printStackTrace();
        }
        req.setCharacterEncoding("Utf-8");
        req.setAttribute("employee", employee);
//
        req.getRequestDispatcher("/demo1/info.jsp").forward(req, resp);

    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doGet(req, resp);
    }
}
