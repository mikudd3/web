package org.mikudd3.web.request;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.Map;
import java.util.Set;

@WebServlet("/RequestDemo1")
public class RequestDemo1 extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //处理数据
        //获取所有参数Map集合
        Map<String, String[]> map = request.getParameterMap();
        for (String key : map.keySet()) {
            System.out.print(key + ":");
            for (String value : map.get(key)) {
                System.out.print(value + " ");
            }
            System.out.println();
        }

        //根据名称获取参数值(数组)
        String[] hobbies = request.getParameterValues("hobby");
        for (String hobby : hobbies) {
            System.out.println("hobby:" + hobby);
        }


        //根据名称获取参数值(单个值)
        String username = request.getParameter("username");
        System.out.println("username:" + username);
        String password = request.getParameter("password");
        System.out.println("password:" + password);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
