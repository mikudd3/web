package org.mikudd3.web;

import org.apache.ibatis.session.SqlSession;
import org.mikudd3.mapper.UserMapper;
import org.mikudd3.pojo.User;
import org.mikudd3.util.SqlSessionFactoryUtils;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/loginServlet")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取表单输入数据
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        //创建SqlSession对象
        SqlSession sqlSession = SqlSessionFactoryUtils.getSqlSessionFactory().openSession();
        //创建mapper对象
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);

        //查询数据
        User user = userMapper.selectUser(username, password);

        //关闭资源
        sqlSession.close();


        //输出中文
        response.setContentType("text/html;charset=utf-8");
        if (user == null) {
            response.getWriter().write("登录失败！");
        } else {
            response.getWriter().write("登录成功！");
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
