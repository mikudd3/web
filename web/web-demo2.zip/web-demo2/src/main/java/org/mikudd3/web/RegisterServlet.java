package org.mikudd3.web;

import org.apache.ibatis.session.SqlSession;
import org.mikudd3.mapper.UserMapper;
import org.mikudd3.pojo.User;
import org.mikudd3.util.SqlSessionFactoryUtils;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet("/registerServlet")
public class RegisterServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取表单输入数据
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        //封装对象
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);

        //创建SqlSession对象
        SqlSession sqlSession = SqlSessionFactoryUtils.getSqlSessionFactory().openSession();
        //创建mapper对象
        UserMapper userMapper = sqlSession.getMapper(UserMapper.class);

        //查询数据
        User u = userMapper.selectByUsername(username);
        //System.out.println(u);
        response.setContentType("text/html;charset=utf-8");
        //3. 判断用户对象释放为null
        if (u == null) {
            // 用户名不存在，添加用户
            userMapper.add(user);
            // 提交事务
            sqlSession.commit();
            // 释放资源
            sqlSession.close();
            response.getWriter().write("注册成功");
        } else {
            // 用户名存在，给出提示信息
            response.getWriter().write("用户名已存在");
        }


    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }
}
