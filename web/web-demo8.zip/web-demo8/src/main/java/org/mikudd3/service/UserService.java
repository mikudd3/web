package org.mikudd3.service;

import com.mysql.cj.Session;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mikudd3.mapper.UserMapper;
import org.mikudd3.pojo.User;
import org.mikudd3.util.SqlSessionFactoryUtils;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class UserService {
    SqlSessionFactory factory = SqlSessionFactoryUtils.getSqlSessionFactory();

    /**
     * 登录
     *
     * @param username
     * @param password
     * @return
     */
    public User login(String username, String password) {
        SqlSession session = factory.openSession();
        UserMapper mapper = session.getMapper(UserMapper.class);
        //调用方法
        User user = mapper.select(username, password);

        session.close();
        return user;
    }

    /**
     * 注册
     *
     * @param user
     * @return
     */
    public boolean register(User user) {
        SqlSession session = factory.openSession();
        UserMapper mapper = session.getMapper(UserMapper.class);

        //判断用户是否存在
        User u = mapper.selectByUsername(user.getUsername());
        if (u == null) {
            mapper.add(user);
            session.commit();
        }
        session.close();
        return u == null;
    }
}
