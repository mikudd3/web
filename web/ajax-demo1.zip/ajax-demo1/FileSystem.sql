


DROP TABLE IF EXISTS `file_list`;

CREATE TABLE `file_list` (
  `id` bigint(12) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `file_name` varchar(200) DEFAULT NULL COMMENT '文件名',
  `file_suffix` varchar(12) DEFAULT NULL COMMENT '后缀名',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `file_size` varchar(12) DEFAULT NULL COMMENT '文件大小',
  `file_url` varchar(200) DEFAULT NULL COMMENT '文件路径',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8;


insert  into `file_list`(`id`,`file_name`,`file_suffix`,`create_time`,`file_size`,`file_url`) values (60,'图书管理系统.txt','txt','2020-12-25 10:21:13','9K','/upload/图书管理系统.txt'),(61,'新建文本文档 - 副本 (2).txt','txt','2020-12-25 10:21:20','776B','/upload/新建文本文档 - 副本 (2).txt'),(62,'新建文本文档 - 副本 (3).txt','txt','2020-12-25 10:21:28','776B','/upload/新建文本文档 - 副本 (3).txt'),(63,'新建文本文档 - 副本 (4).txt','txt','2020-12-25 10:21:35','776B','/upload/新建文本文档 - 副本 (4).txt'),(64,'新建文本文档 - 副本 (5).txt','txt','2020-12-25 10:21:41','776B','/upload/新建文本文档 - 副本 (5).txt'),(65,'新建文本文档 - 副本 (6).txt','txt','2020-12-25 10:21:47','776B','/upload/新建文本文档 - 副本 (6).txt');

CREATE TABLE `file_user` (
  `id` bigint(12) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `user_name` varchar(12) DEFAULT NULL COMMENT '用户名',
  `user_pass` varchar(12) DEFAULT NULL COMMENT '密码',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `user_email` varchar(50) DEFAULT NULL COMMENT '邮箱',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8


