package org.lanqiao.dao;

import org.lanqiao.entity.FileUser;

public interface FileUserDao {
    /**
     * 查询用户是否存在
     * @param userName
     * @return
     */
    FileUser findUserByUserName(String userName);

    /**
     * 保存用户
     * @param fileUser
     * @return
     */
    Boolean saveUser(FileUser fileUser);
}
