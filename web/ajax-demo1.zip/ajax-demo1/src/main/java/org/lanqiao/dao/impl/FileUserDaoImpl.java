package org.lanqiao.dao.impl;

import org.lanqiao.dao.FileUserDao;
import org.lanqiao.entity.FileUser;
import org.lanqiao.util.DBUtil;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

public class FileUserDaoImpl implements FileUserDao {

    @Override
    public FileUser findUserByUserName(String userName) {
        String sql = "select * from file_user where user_name = ? ";
        Object[] os = {userName};
        FileUser fl = null;
        try {
            ResultSet rs = DBUtil.query(sql, os);
            if (rs.next()) {
                // 将查询到的信息封装到对象中
                Long user_id = rs.getLong("id");
                String user_name = rs.getString("user_name");
                String user_pass = rs.getString("user_pass");
                Timestamp dateTime = rs.getTimestamp("create_time");
                String user_email = rs.getString("user_email");
                fl = new FileUser(user_id,user_name,user_pass,dateTime,user_email);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return fl;
    }

    @Override
    public Boolean saveUser(FileUser fileUser) {
        String sql = "INSERT INTO file_user (user_name,user_pass,create_time,user_email) VALUE (?,?,?,?)";
        Object[] os ={fileUser.getUserName(),fileUser.getUserPass(),fileUser.getCreateTime(),fileUser.getUserEmail()};
        return DBUtil.execute(sql, os);
    }
}
