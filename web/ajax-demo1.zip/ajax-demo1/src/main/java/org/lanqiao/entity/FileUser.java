package org.lanqiao.entity;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


public class FileUser implements Serializable {


    private static final long serialVersionUID = 1L;

    /**
     * id
     */
    private Long id;

    /**
     * user_name
     */
    private String userName;

    /**
     * user_pass
     */
    private String userPass;

    /**
     * 创建时间
     */
    private Timestamp createTime;

    /**
     * user_email
     */
    private String userEmail;

    /**
     * 格式化时间格式
     */
    private String timeStr;

    public FileUser(String userName, String userPass, String userEmail) {
        this.userName=userName;
        this.userPass=userPass;
        this.userEmail=userEmail;
    }

    public FileUser(Long user_id, String user_name, String user_pass, Timestamp dateTime, String user_email) {
        this.id=user_id;
        this.userName=user_name;
        this.userPass=user_pass;
        this.userEmail=user_email;
        this.createTime=dateTime;
    }

    public FileUser(String userName, String userPass) {
        this.userName=userName;
        this.userPass=userPass;
    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserPass() {
        return userPass;
    }

    public void setUserPass(String userPass) {
        this.userPass = userPass;
    }


    public Timestamp getCreateTime() {return createTime; }

    public void setCreateTime(Timestamp createTime) {
        this.createTime = createTime;
        try {
            DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            this.timeStr = sdf.format(this.createTime);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

}