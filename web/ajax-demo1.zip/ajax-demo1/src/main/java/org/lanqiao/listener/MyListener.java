package org.lanqiao.listener;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * @project: 使用监听器累计网页访问次数
 * @author: mikudd3
 * @version: 1.0
 */
public class MyListener implements HttpSessionListener {

    int count = 0;
    @Override
    public void sessionCreated(HttpSessionEvent httpSessionEvent) {

        // 每当 HttpSession 对象被创建时，执行这个方法
        // 在这里可以增加在线访问人数的计数器
        //每当有人访问，则计数器加一
        /*使用监听器累计网页访问次数
        count++;
        httpSessionEvent.getSession().getServletContext().setAttribute("count", count);*/





    }

    @Override
    public void sessionDestroyed(HttpSessionEvent httpSessionEvent) {
        // 每当 HttpSession 对象被销毁时，执行这个方法
        // 在这里可以减少在线访问人数的计数器
    }
}
