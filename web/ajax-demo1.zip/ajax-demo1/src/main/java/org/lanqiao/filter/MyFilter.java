package org.lanqiao.filter;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Map;

/**
 * @project: 分 IP 统计访问次数
 * @author: mikudd3
 * @version: 1.0
 */
public class MyFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // do nothing
    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        //获取servletContext对象
        ServletContext servletContext = servletRequest.getServletContext();
        //获取map数组
        Map<String, Integer> ipCountMap = (Map<String, Integer>) servletContext.getAttribute("ipCountMap");
        //转为httpServletRequest对象
        HttpServletRequest httpServletRequest = (HttpServletRequest) servletRequest;
        //获取id
        String ip = httpServletRequest.getRemoteAddr();
        //判断是否已经含有改ip
        if (ipCountMap.containsKey(ip)) {
            int count = ipCountMap.get(ip);
            count += 1;
            ipCountMap.put(ip, count);
        } else {
            ipCountMap.put(ip, 1);
        }
        //放行
        filterChain.doFilter(servletRequest, servletResponse);
    }

    @Override
    public void destroy() {
        // do nothing
    }

}
