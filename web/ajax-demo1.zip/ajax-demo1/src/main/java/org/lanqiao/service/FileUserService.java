package org.lanqiao.service;

import org.lanqiao.entity.FileUser;
import org.lanqiao.util.ResponseMessage;

public interface FileUserService {

    /**
     * 注册用户
     * @param fileUser 用信息
     * @param rm 返回值
     * @return
     */
    ResponseMessage registUser(FileUser fileUser, ResponseMessage rm);

    /**
     * 登录
     * @param fileUser
     * @param rm
     * @return
     */
    ResponseMessage loginUser(FileUser fileUser, ResponseMessage rm);
}
