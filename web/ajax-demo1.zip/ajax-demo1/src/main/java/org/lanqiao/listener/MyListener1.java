package org.lanqiao.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import java.util.HashMap;
import java.util.Map;

/**
 * @project: 分 IP 统计访问次数
 * @author: mikudd3
 * @version: 1.0
 */
public class MyListener1 implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent servletContextEvent) {
        //创建map集合
        Map<String, Integer> ipCountMap = new HashMap<String, Integer>();
        //发送到fitter
        servletContextEvent.getServletContext().setAttribute("ipCountMap", ipCountMap);
    }

    @Override
    public void contextDestroyed(ServletContextEvent servletContextEvent) {

    }
}
