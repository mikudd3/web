package org.lanqiao.service.serviceimpl;

import org.lanqiao.dao.UserDao;
import org.lanqiao.entity.User;
import org.lanqiao.jdbc.DbUtil;
import org.lanqiao.service.UserService;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class UserServiceImpl implements UserService {

    private UserDao userDao = new UserDao();

    @Override
    public boolean addUser(User user) {
        return userDao.add(user);
    }
}
