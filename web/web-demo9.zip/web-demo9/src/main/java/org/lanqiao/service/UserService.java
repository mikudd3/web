package org.lanqiao.service;

import org.lanqiao.entity.User;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public interface UserService {

    boolean addUser(User user);
}
