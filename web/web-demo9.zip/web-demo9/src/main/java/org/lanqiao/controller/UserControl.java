package org.lanqiao.controller;

import org.lanqiao.entity.User;
import org.lanqiao.service.serviceimpl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */

@WebServlet("/addUserInfo")
public class UserControl extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // 从前端页面获取表单数据
        String username = request.getParameter("username");
        String gender = request.getParameter("gender");
        String age = request.getParameter("age");
        String nation = request.getParameter("nation");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String addr = request.getParameter("addr");

        //封装对象
        User user = new User();
        user.setName(username);
        user.setAge(gender == "男" ? 1 : 0);
        user.setAge(Integer.parseInt(age));
        user.setNation(nation);
        user.setEmail(email);
        user.setPhone(phone);
        user.setAddr(addr);

        //添加数据
        UserServiceImpl userService = new UserServiceImpl();
        userService.addUser(user);


    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        this.doPost(req, resp);
    }
}
