package org.lanqiao.dao;

import org.lanqiao.entity.User;
import org.lanqiao.jdbc.DbUtil;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class UserDao {
    public boolean add(User user) {
        String sql = "insert into users values(null,?,?,?,?,?,?,?)";
        Object[] os = {
                user.getName(), user.getGender(), user.getAge(), user.getNation(),
                user.getEmail(), user.getPhone(), user.getAddr()
        };
        //执行查询
        return DbUtil.execute(sql, os);
    }
}
