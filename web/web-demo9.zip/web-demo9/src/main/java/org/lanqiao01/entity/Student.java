package org.lanqiao01.entity;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class Student {
    private int studentNo;
    private String studentName;
    // 地址属性
    private Address address;

    public int getStudentNo() {
        return studentNo;
    }

    public void setStudentNo(int studentNo) {
        this.studentNo = studentNo;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public Student(int studentNo, String studentName, Address address) {
        this.studentNo = studentNo;
        this.studentName = studentName;
        this.address = address;
    }

    public Student() {
    }
}