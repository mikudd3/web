package org.lanqiao01.servlet;

import org.lanqiao01.entity.Student;
import org.lanqiao01.entity.Address;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class InitServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        this.doPost(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Address address = new Address();
        address.setHomeAddress("北京朝阳区");
        address.setSchoolAddress("北京**中心");

        Student student = new Student();
        student.setStudentNo(27);
        student.setStudentName("颜群");
        student.setAddress(address);

        request.setAttribute("student", student);
        request.getRequestDispatcher("/demo2/info.jsp").forward(request, response);
    }
}