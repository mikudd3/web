package org.lanqiao01.entity;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class Address {
    // 家庭地址
    private String homeAddress;
    // 学校地址
    private String schoolAddress;

    public String getHomeAddress() {
        return homeAddress;
    }

    public void setHomeAddress(String homeAddress) {
        this.homeAddress = homeAddress;
    }

    public String getSchoolAddress() {
        return schoolAddress;
    }

    public void setSchoolAddress(String schoolAddress) {
        this.schoolAddress = schoolAddress;
    }

    public Address() {
    }

    public Address(String homeAddress, String schoolAddress) {
        this.homeAddress = homeAddress;
        this.schoolAddress = schoolAddress;
    }
}
