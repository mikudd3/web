package org.mikudd3.dao.daoimpl;

import org.lanqiao.jdbc.DbUtil;
import org.mikudd3.dao.GoodDao;
import org.mikudd3.entity.Good;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class GoodDaoImpl implements GoodDao {

    /**
     * 查询所有商品
     *
     * @return 包含所有商品的集合
     */
    @Override
    public List<Good> getGoods() throws SQLException {
        String sql = "select * from goods";
        Object[] os = null;
        List<Good> goods = new ArrayList<>();
        try {
            ResultSet rs = DbUtil.query(sql, os);
            while (rs.next()) {
                Integer goodId = rs.getInt("good_id");
                String name = rs.getString("good_name");
                String goodManufacturer = rs.getString("good_manufacturer");
                double goodPrice = rs.getDouble("good_price");
                int state = rs.getInt("good_state");
                int goodInventory = rs.getInt("good_Inventory");
                //创建good
                Good good = new Good();
                good.setGoodId(goodId);
                good.setGoodName(name);
                good.setGoodManufacturer(goodManufacturer);
                good.setGoodPrice(BigDecimal.valueOf(goodPrice));
                good.setGoodState(state);
                good.setGoodInventory(goodInventory);
                //加入集合
                goods.add(good);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return goods;
    }

    /**
     * 通过商品名称查询商品
     *
     * @return 查询出的商品
     */
    @Override
    public List<Good> getGoodByName(String goodName) throws SQLException {
        String sql = "select * from goods where good_name like ?";
        Object[] os = {"%" + goodName + "%"};
        List<Good> goods = new ArrayList<>();
        try {
            ResultSet rs = DbUtil.query(sql, os);
            while (rs.next()) {
                Integer goodId = rs.getInt("good_id");
                String name = rs.getString("good_name");
                String goodManufacturer = rs.getString("good_manufacturer");
                double goodPrice = rs.getDouble("good_price");
                int state = rs.getInt("good_state");
                int goodInventory = rs.getInt("good_Inventory");
                //创建good
                Good good = new Good();
                good.setGoodId(goodId);
                good.setGoodName(name);
                good.setGoodManufacturer(goodManufacturer);
                good.setGoodPrice(BigDecimal.valueOf(goodPrice));
                good.setGoodState(state);
                good.setGoodInventory(goodInventory);
                //加入集合
                goods.add(good);
            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return goods;
    }

    /**
     * 新增商品到数据库
     *
     * @param good 新增的商品对象
     * @return 新增成功与否
     */
    @Override
    public boolean addGood(Good good) {
        String sql = "insert into goods values(null,?,?,?,?,?)";
        Object[] os = {good.getGoodName(), good.getGoodManufacturer(), good.getGoodPrice(),
                good.getGoodState(), good.getGoodInventory()};
        return DbUtil.execute(sql, os);
    }

    /**
     * 通过商品 id 查询商品
     *
     * @return 查询出的商品
     */
    @Override
    public Good getGoodByGoodId(int goodId) throws SQLException {
        String sql = "select * from goods where good_id = ?";
        Object[] os = {goodId};
        Good good = new Good();
        try {
            ResultSet rs = DbUtil.query(sql, os);
            while (rs.next()) {
                String name = rs.getString("good_name");
                String goodManufacturer = rs.getString("good_manufacturer");
                double goodPrice = rs.getDouble("good_price");
                int state = rs.getInt("good_state");
                int goodInventory = rs.getInt("good_Inventory");

                good.setGoodId(goodId);
                good.setGoodName(name);
                good.setGoodManufacturer(goodManufacturer);
                good.setGoodPrice(BigDecimal.valueOf(goodPrice));
                good.setGoodState(state);
                good.setGoodInventory(goodInventory);

            }
            rs.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return good;
    }

    /**
     * 通过商品 id 删除商品
     *
     * @return 是否删除成功
     */
    @Override
    public boolean deleteGood(int goodId) {
        String sql = "delete from goods where good_id = ?";
        Object[] os = {goodId};
        return DbUtil.execute(sql, os);
    }

    @Override
    public boolean updateGood(Good good) {
        String sql = "update goods set good_name = ?,good_manufacturer = ?," +
                "good_price = ?,good_state = ?,good_Inventory = ? where good_id = ?";
        Object[] os = {
                good.getGoodName(), good.getGoodManufacturer(), good.getGoodPrice(),
                good.getGoodState(), good.getGoodInventory(), good.getGoodId()
        };

        return DbUtil.execute(sql, os);
    }


}
