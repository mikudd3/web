package org.mikudd3.service.serviceimpl;

import org.mikudd3.dao.daoimpl.GoodDaoImpl;
import org.mikudd3.entity.Good;
import org.mikudd3.service.GoodService;

import java.sql.SQLException;
import java.util.List;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class GoodServiceImpl implements GoodService {
    private GoodDaoImpl dao = new GoodDaoImpl();

    /**
     * 查询所有商品
     *
     * @return 包含所有商品的集合
     */
    @Override
    public List<Good> getGoods() {
        List<Good> goods = null;
        try {
            goods = dao.getGoods();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return goods;
    }

    /**
     * 通过商品名称查询商品
     *
     * @return 查询出的商品
     */
    @Override
    public List<Good> getGoodByName(String goodName) {
        List<Good> goods = null;
        try {
            goods = dao.getGoodByName(goodName);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return goods;
    }

    /**
     * 新增商品到数据库
     *
     * @param good 新增的商品对象
     * @return 新增成功与否
     */
    @Override
    public boolean addGood(Good good) {
        return dao.addGood(good);
    }

    /**
     * 通过商品 id 查询商品
     *
     * @return 查询出的商品
     */
    @Override
    public Good getGoodById(int goodId) {
        Good goodByGoodId = null;
        try {
            goodByGoodId = dao.getGoodByGoodId(goodId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return goodByGoodId;
    }

    /**
     * 通过商品 id 删除商品
     *
     * @return 是否删除成功
     */
    @Override
    public boolean deleteGood(int goodId) {
        return dao.deleteGood(goodId);
    }

    /**
     * 更新商品
     *
     * @param good
     */
    @Override
    public boolean updateGood(Good good) {
        return dao.updateGood(good);

    }


}
