package org.mikudd3.dao;



import org.mikudd3.entity.Good;

import java.sql.SQLException;
import java.util.List;

public interface GoodDao {
    /**
     * 查询所有商品
     * @return 包含所有商品的集合
     */
    List<Good> getGoods() throws SQLException;

    /**
     * 通过商品名称查询商品
     * @return 查询出的商品
     */
    List<Good> getGoodByName(String goodName) throws SQLException;

    /**
     * 新增商品到数据库
     * @param good 新增的商品对象
     * @return 新增成功与否
     */
    boolean addGood(Good good);

    /**
     * 通过商品 id 查询商品
     * @return 查询出的商品
     */
    Good getGoodByGoodId(int goodId) throws SQLException;

    /**
     * 通过商品 id 删除商品
     * @return 是否删除成功
     */
    boolean deleteGood(int goodId);

    /**
     * 更新商品
     * @param good
     */
    boolean updateGood(Good good);

}
