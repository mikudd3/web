package org.mikudd3.controller;


import org.mikudd3.entity.Good;
import org.mikudd3.service.GoodService;
import org.mikudd3.service.serviceimpl.GoodServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

@WebServlet("/GoodController/*")
public class GoodController extends HttpServlet {
    //  创建 service 对象
    GoodService gs = new GoodServiceImpl();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doGet(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//      获取访问的路径
        StringBuffer requestURL = request.getRequestURL();
//      将最后一段路径截取出来用作判断方法名
        String methonName = requestURL.substring(requestURL.lastIndexOf("/") + 1);
//      用 switch 判断该执行哪个方法。
        switch (methonName) {
            case "getGoods":
                getGoods(request, response);
                break;
            case "getGoodByName":
                getGoodByName(request, response);
                break;
            case "updateGood":
                updateGood(request, response);
                break;
            case "deleteGood":
                deleteGood(request, response);
                break;
            case "addGood":
                addGood(request, response);
                break;
            default:
        }
    }

    /**
     * 新增商品
     */
    private void addGood(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        //存储的名字是中文的解决
        String goodName = new String(request.getParameter("goodName").getBytes("ISO-8859-1"), "UTF-8");
        String goodManufacturer = new String(request.getParameter("goodManufacturer").getBytes("ISO-8859-1"), "UTF-8");
        String goodPrice = request.getParameter("goodPrice");
        String goodState = request.getParameter("goodState");
        String goodInventory = request.getParameter("goodInventory");
        // 将数据封装到实体类中
        Good good = new Good();
        good.setGoodName(goodName);
        good.setGoodManufacturer(goodManufacturer);
        good.setGoodPrice(BigDecimal.valueOf(Integer.parseInt(goodPrice)));
        good.setGoodState(Integer.parseInt(goodState));
        good.setGoodInventory(Integer.parseInt(goodInventory));
        // 调用业务逻辑层代码
        boolean result = gs.addGood(good);

        if (!result) {
            // 如果增加失败，则在 request 中放入一个标识符，标识一下错误
            request.setAttribute("errorInfo", "error");
            // 返回增加页面。因为需要传递 request 作用域中的数据，所以使用请求转发
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        } else {
            response.sendRedirect("/web-demo9/GoodController/getGoods");
        }
    }

    /**
     * 查询所有商品
     */
    private void getGoods(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        // 调用业务逻辑层代码
        //System.out.println(11111);
        List<Good> goods = gs.getGoods();
        request.setAttribute("goods", goods);
        request.getRequestDispatcher("/allGoods.jsp").forward(request, response);
    }

    /**
     * 通过商品名称查询商品
     */
    private void getGoodByName(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        // 接收需要显示学生的学号
        String goodName = new String(request.getParameter("good_name").getBytes("ISO-8859-1"), "UTF-8");
//        System.out.println(goodName);
        // 调用业务逻辑层代码
        List<Good> goods = gs.getGoodByName(goodName);
//        System.out.println(goods);
        // 将查询到的学生信息放入 request 作用域中
        request.setAttribute("goods", goods);
        request.getRequestDispatcher("/allGoods.jsp").forward(request, response);
    }


    /**
     * 删除商品
     */
    private void deleteGood(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 接收通过地址重写传递来的参数
        String goodId = request.getParameter("goodId");
        // 调用业务逻辑层代码
        boolean result = gs.deleteGood(Integer.parseInt(goodId));
        if (!result) {
            // 如果增加失败，则在 request 中放入一个标识符，标识一下错误
            request.setAttribute("errorInfo", "error");
        }
        // 因为需要传递 request 作用域中的数据（错误标识符），
        // 所以使用请求转发
        request.getRequestDispatcher("/GoodController/getGoods").forward(request, response);
    }


    private void updateGood(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String goodId = request.getParameter("goodId");
        String goodName = request.getParameter("goodName");
        String goodManufacturer = request.getParameter("goodManufacturer");
        String goodPrice = request.getParameter("goodPrice");
        String goodState = request.getParameter("goodState");
        String goodInventory = request.getParameter("goodInventory");

        //封装对象
        Good good = new Good();
        good.setGoodId(Integer.parseInt(goodId));
        good.setGoodName(goodName);
        good.setGoodManufacturer(goodManufacturer);
        good.setGoodPrice(BigDecimal.valueOf(Integer.parseInt(goodPrice)));
        good.setGoodState(Integer.parseInt(goodState));
        good.setGoodInventory(Integer.parseInt(goodInventory));

        boolean result = gs.updateGood(good);
        if (!result) {
            // 如果增加失败，则在 request 中放入一个标识符，标识一下错误
            request.setAttribute("errorInfo", "error");
        }
        // 因为需要传递 request 作用域中的数据（错误标识符），
        // 所以使用请求转发
        request.getRequestDispatcher("/web-demo9/GoodController/getGoods").forward(request, response);

    }

}
