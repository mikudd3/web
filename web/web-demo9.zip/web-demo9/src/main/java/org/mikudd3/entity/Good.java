package org.mikudd3.entity;

import java.math.BigDecimal;
import java.util.Objects;

public class Good {
    private Integer goodId;
    private String goodName;
    private String goodManufacturer;
    private BigDecimal goodPrice;
    private Integer goodState;
    private Integer goodInventory;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Good good = (Good) o;
        return goodId == good.goodId &&
                goodState == good.goodState &&
                goodInventory == good.goodInventory &&
                Objects.equals(goodName, good.goodName) &&
                Objects.equals(goodManufacturer, good.goodManufacturer) &&
                Objects.equals(goodPrice, good.goodPrice);
    }

    @Override
    public int hashCode() {
        return Objects.hash(goodId, goodName, goodManufacturer, goodPrice, goodState, goodInventory);
    }

    @Override
    public String toString() {
        return "Good{" +
                "goodId=" + goodId +
                ", goodName='" + goodName + '\'' +
                ", goodManufacturer='" + goodManufacturer + '\'' +
                ", price=" + goodPrice +
                ", goodState=" + goodState +
                ", goodInventory=" + goodInventory +
                '}';
    }

    public Good() {
    }

    public Good(Integer goodId, String goodName, String goodManufacturer, BigDecimal goodPrice, int goodState, int goodInventory) {
        this.goodId = goodId;
        this.goodName = goodName;
        this.goodManufacturer = goodManufacturer;
        this.goodPrice = goodPrice;
        this.goodState = goodState;
        this.goodInventory = goodInventory;
    }

    public Good(String goodName, String goodManufacturer, BigDecimal goodPrice, int goodState, int goodInventory) {
        this.goodName = goodName;
        this.goodManufacturer = goodManufacturer;
        this.goodPrice = goodPrice;
        this.goodState = goodState;
        this.goodInventory = goodInventory;
    }

    public void setGoodId(int goodId) {
        this.goodId = goodId;
    }

    public void setGoodName(String goodName) {
        this.goodName = goodName;
    }

    public void setGoodManufacturer(String goodManufacturer) {
        this.goodManufacturer = goodManufacturer;
    }

    public void setGoodPrice(BigDecimal goodPrice) {
        this.goodPrice = goodPrice;
    }

    public void setGoodState(int goodState) {
        this.goodState = goodState;
    }

    public void setGoodInventory(int goodInventory) {
        this.goodInventory = goodInventory;
    }

    public int getGoodId() {
        return goodId;
    }

    public String getGoodName() {
        return goodName;
    }

    public String getGoodManufacturer() {
        return goodManufacturer;
    }

    public BigDecimal getGoodPrice() {
        return goodPrice;
    }

    public int getGoodState() {
        return goodState;
    }

    public int getGoodInventory() {
        return goodInventory;
    }


}
