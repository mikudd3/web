package org.mikudd3.test;

import org.junit.Test;
import org.mikudd3.entity.Good;
import org.mikudd3.service.serviceimpl.GoodServiceImpl;

import java.math.BigDecimal;
import java.util.List;

/**
 * @project:
 * @author: mikudd3
 * @version: 1.0
 */
public class TestGood {

    private GoodServiceImpl gs = new GoodServiceImpl();

    //新增商品
    @Test
    public void testAdd() {
        Good good = new Good();
        good.setGoodId(12);
        good.setGoodName("小米");
        good.setGoodManufacturer("小米");
        good.setGoodPrice(BigDecimal.valueOf(12.333));
        good.setGoodState(1);
        good.setGoodInventory(12000);

        boolean result = gs.addGood(good);
        System.out.println(result);

    }

    //查询所有商品
    @Test
    public void testGetGoods() {
        List<Good> goods = gs.getGoods();
        System.out.println(goods);
    }


    //通过商品名称查询商品
    @Test
    public void testGetGoodByName() {
        List<Good> goodByName = gs.getGoodByName("小米");
        System.out.println(goodByName);
    }


    //删除商品
    @Test
    public void testDeleteGood() {
        boolean result = gs.deleteGood(15);
        System.out.println(result);
    }

    //修改商品信息
    @Test
    public void testUpdateGood() {
        Good good = new Good();
        good.setGoodId(9);
        good.setGoodName("百事可乐");
        good.setGoodManufacturer("百事可乐");
        good.setGoodPrice(BigDecimal.valueOf(3.000));
        good.setGoodState(1);
        good.setGoodInventory(12000);

        gs.updateGood(good);
    }

}
